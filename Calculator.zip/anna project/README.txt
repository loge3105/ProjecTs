First install eel in your computer
open your cmd type
"pip install eel"

and double click the main.py file